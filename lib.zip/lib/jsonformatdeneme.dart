import 'dart:convert';
import 'dart:io';

void main() {
  // Dosya yolu
  String filePath = "assets/save.json";

  // Dosyayı oku
  File file = File(filePath);
  String jsonString = file.readAsStringSync();

  // JSON verisini parse et
  Map<String, dynamic> data = jsonDecode(jsonString);

  // İlk egzersizi seç
  var firstExercise = data['exercises'].first;

  // Egzersizi işle
  String fitness = firstExercise['fitness'];
  print('Fitness: $fitness');
  List<dynamic> landmarkstype = firstExercise['landmarkstype'];
  print(landmarkstype[0]["type"]);

  for (int i = 0; i < landmarkstype.length; i++) {
    final connection = landmarkstype[i];
    List<String> types = (connection["type"] as String).split(",");
    print(connection["x"]);
    print(connection["y"]);
    print(types[0]);
    print(types[1]);
    print("-------------------------");
  }
  for (var landmarks in landmarkstype) {
    String type = landmarks['type'];
    List<String> types = type.split(',');
    print(types);
    for (var connecters in types) {
      connecters = connecters.trim(); // Boşlukları kaldır
      print('Separated Type: $connecters');
    }
    int x = landmarks['x'];
    int y = landmarks['y'];
    print('X: $x, Y: $y');
  }
  print('');
}
