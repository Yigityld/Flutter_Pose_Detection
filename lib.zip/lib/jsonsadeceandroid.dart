import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // path_provider kullanmıyoruz

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Map<String, dynamic> data = {};

  @override
  void initState() {
    super.initState();
    _loadJsonData();
  }

  Future<void> _loadJsonData() async {
    String jsonString = await rootBundle.loadString('assets/save.json');
    setState(() {
      data = jsonDecode(jsonString);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exercise Data'),
      ),
      body: Center(
        child: data.isNotEmpty
            ? ExerciseDetails(exercise: data['exercises'].first)
            : CircularProgressIndicator(),
      ),
    );
  }
}

class ExerciseDetails extends StatelessWidget {
  final Map<String, dynamic> exercise;

  ExerciseDetails({required this.exercise});

  @override
  Widget build(BuildContext context) {
    List<dynamic> landmarkstype = exercise['landmarkstype'];
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text('Fitness: ${exercise['fitness']}'),
        SizedBox(height: 20),
        ListView.builder(
          shrinkWrap: true,
          itemCount: landmarkstype.length,
          itemBuilder: (context, index) {
            final connection = landmarkstype[index];
            List<String> types = (connection["type"] as String).split(",");
            return Column(
              children: [
                Text('X: ${connection["x"]}'),
                Text('Y: ${connection["y"]}'),
                Text(types[0]),
                Text(types[1]),
                SizedBox(height: 10),
              ],
            );
          },
        ),
      ],
    );
  }
}
